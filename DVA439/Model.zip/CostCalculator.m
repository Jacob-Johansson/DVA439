function cost = CostCalculator(heatFlow, costPerJoule)
cost = heatFlow * costPerJoule;
end

